package jp.kobe_u.cs.daikibo.tsubuyaki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TsubuyakiApplicationTests {

	@Test
	void contextLoads() {
	}

}
